package berg.jesterchat;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

/**
 * Created by Alexander on 19.10.2017.
 */

public class ChamberChat extends AppCompatActivity
{
    ChamberChatAdapter cAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chamber_chat);

        Intent intent = getIntent();
        int cID = intent.getIntExtra(EntryHall.ChamberID, 0);
        setTitle("Chamber " + cID);

        RecyclerView rv = (RecyclerView) findViewById(R.id.rvChat);
        rv.setLayoutManager(new LinearLayoutManager(this));
        cAdapter = new ChamberChatAdapter(this);
        rv.setAdapter(cAdapter);

        try
        {
            new LoadCCMessages(new LoadCCMessages.OnPostExecute()
            {
                @Override
                public void onPostExecute(List<CCMessage> ccmessages)
                {
                    cAdapter.setMessages(ccmessages);
                }
            }).execute(new URL("https://alexaneb-tjener.uials.no:1313//ChatApplication/api/messages?name=" + cID));
        } catch (MalformedURLException e)
        {
            e.printStackTrace();
        }
    }

    /**
     *
     */
    public void sendMessage(View view)
    {
        EditText enterMsg = (EditText) findViewById(R.id.ccMessage);
        String message = enterMsg.getText().toString();

        postMessage(message);
    }

    /**
     *
     */
    public void postMessage(String msg)
    {
        TextView textView = (TextView) findViewById(R.id.ccMessageView); //?
        textView.setText(msg);
    }
}
