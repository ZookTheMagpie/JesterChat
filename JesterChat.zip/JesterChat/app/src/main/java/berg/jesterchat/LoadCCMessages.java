package berg.jesterchat;

import android.os.AsyncTask;
import android.util.JsonReader;
import android.util.Log;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * Created by Alexander on 19.10.2017.
 */

public class LoadCCMessages extends AsyncTask<URL, Integer, List<CCMessage>>
{
    @Override
    protected List<CCMessage> doInBackground(URL... urls)
    {
        if(urls.length < 1)
        {
            return Collections.EMPTY_LIST;
        }

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        List<CCMessage> result = new ArrayList<>();

        HttpURLConnection con = null;
        try
        {
            con = (HttpURLConnection)urls[0].openConnection();
            JsonReader jr = new JsonReader((new InputStreamReader(con.getInputStream())));
            jr.beginArray();
            while(jr.hasNext())
            {
                String username = null;
                String message = null;
                Date date = null;

                jr.beginObject();
                while(jr.hasNext())
                {
                    switch(jr.nextName())
                    {
                        case "message":
                            message = jr.nextString();
                            break;
                        case "username":
                            username = jr.nextString();
                            break;
                        case "date":
                            try
                            {
                                date = format.parse(jr.nextString());
                            }   catch (ParseException e)
                            {
                                Log.e("LoadCCMessage", "Failed to parse date", e);
                            }
                            break;
                        default:
                            jr.skipValue();
                    }
                }
                jr.endObject();
                result.add(new CCMessage(message,username,date));
            }
            jr.endArray();
        } catch (IOException e) {
            Log.e("LoadCCMessages","Failed to load messages from: " + urls[0],e);
        }
        return result;
    }

    @Override
    protected void onPostExecute(List<CCMessage> messages)
    {
        if (callback != null)
        {
            callback.onPostExecute(messages);
        }
    }

    public interface OnPostExecute {
        void onPostExecute(List<CCMessage> messages);
    }
    OnPostExecute callback;
    public LoadCCMessages(OnPostExecute callback)
    {
        this.callback = callback;
    }


}
