package berg.jesterchat;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class EntryHall extends AppCompatActivity {
    public static final String ChamberID = "berg.JesterChat.chamber";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entry_hall);
    }

    public void chamberCreation(View view)
    {
        int cName = 0;

        switch (view.getId())
        {
            case R.id.cButton1:
                cName = 1;
                break;
            case R.id.cButton2:
                cName = 2;
                break;
            case R.id.cButton3:
                cName = 3;
                break;
        }

        Intent intent = new Intent(this, ChamberChat.class);
        intent.putExtra(ChamberID, cName);
        startActivity(intent);
    }
}
